//
//  ErrorController.h
//  UglyMan_Stitching
//
//  Created by uglyman.nothinglo on 2015/8/15.
//  Copyright (c) 2015 nothinglo. All rights reserved.
//

#ifndef __UglyMan_Stitiching__ErrorController__
#define __UglyMan_Stitiching__ErrorController__

#include <iostream>
#include <string>

using namespace std;

void printError(const string _error);

#endif /* defined(__UglyMan_Stitiching__ErrorController__) */
