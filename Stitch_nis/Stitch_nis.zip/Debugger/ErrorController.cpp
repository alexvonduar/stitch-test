//
//  ErrorController.cpp
//  UglyMan_Stitching
//
//  Created by uglyman.nothinglo on 2015/8/15.
//  Copyright (c) 2015 nothinglo. All rights reserved.
//

#include "ErrorController.h"

void printError(const string _error) {
    cerr << "[ERROR] " << _error << endl;
}